# Tindahan — Component Inventory

Every reusable component in `css/components.css`, what it's for, and how
not to misuse it. Class names are exact and match the CSS/HTML in this
repo.

---

### Button — `.btn`
**Purpose:** Every clickable action in the app.
**Variants:** `.btn-primary` `.btn-secondary` `.btn-soft` `.btn-ghost`
`.btn-danger` `.btn-accent`. Sizes: `.btn-sm` `.btn-lg` (default is the
base size). `.btn-block` for full-width. `.btn-icon` for icon-only
(square, 44×44).
**States:** default, hover, `:active` (1px press), `:disabled`,
`.btn-loading` (spinner replaces label, label kept for screen readers via
`color: transparent` — text stays in the DOM).
**Accessibility:** 44px minimum height on every size. Icon-only buttons
**must** carry `aria-label`.
**Misuse to avoid:** Never more than one `.btn-primary` visible at a time
on a screen. Never an icon-only primary action without a label.

### Input / Select / Textarea — `.input` `.select` `.textarea`
**Purpose:** Form fields, always paired with `.field` + `.field-label`.
**States:** default, hover, focus (`--shadow-focus` ring, never removed),
`.has-error`, `:disabled`.
**Accessibility:** Always associated to a `<label for>`. Error state pairs
with `.field-error` text directly below the field (inline, not a toast) —
"inline validation close to the relevant field" per the PRD.
**Misuse to avoid:** Never rely on placeholder text as a label substitute.

### Stepper — `.stepper`
**Purpose:** Quantity input (sales lines, stock adjustment). Two buttons +
a numeric input.
**Behavior:** `data-max` on the inner `<input>` clamps the ceiling (stock
on hand); reaching it adds `.stepper-at-max`. Fires a `stepper:change`
custom event other components can listen for (used by Record Sale to
recompute totals).
**Accessibility:** Both buttons carry `aria-label`; the input carries a
specific `aria-label` naming the product.

### Badge — `.badge`
**Purpose:** A short status word, always icon + text — **never color
alone**.
**Variants:** `-success` `-warning` `-danger` `-info` `-neutral` `-olive`.
**Misuse to avoid:** Never a bare color dot as a status indicator; always
pair with a word (see `notif-dot`, which is a *supplementary* indicator
next to a fully-worded row, not the only signal).

### Card — `.card`
**Purpose:** The base surface for every grouped piece of content.
**Variants:** `.card-tint-cream` (Attention Required), `.card-tint-brand`
(emerald, Quick Actions), `.card-tint-olive` (Insights), `.card-link`
(hoverable/clickable card).
**Rule:** One card = one question. If a card needs a second heading, it
should be two cards.

### Attention item — `.attn-item` / `.attn-icon`
**Purpose:** A single actionable alert row on the Dashboard.
**Anatomy:** icon (in a tinted 40×40 square) + title + meta + a single
action button.
**Tones:** `.warning` `.danger` `.info`.

### Quick action tile — `.quick-action`
**Purpose:** One-tap entry into a hero workflow from the Dashboard.
**Anatomy:** icon in a soft-emerald square + label. Always a link, never a
button that opens a nested menu.

### Chip / filter — `.chip`, `.chip-row`
**Purpose:** Single-select-style filters (Inventory status, Receipts
status, Search categories).
**States:** default, hover, `.active`.
**Misuse to avoid:** Don't use chips for multi-select unless the visual
design changes to communicate that (checkmarks, not just active fill).

### Segmented control — `.segmented`
**Purpose:** A small, closed set of mutually exclusive options (time
range, language, theme-in-settings).
**Difference from chips:** Chips filter a list and can imply counts;
segmented controls switch a view/mode.

### Row item — `.row-item`, `.row-list`
**Purpose:** The default list-row pattern used everywhere data is listed
(inventory, search results, activity feed, receipts). Deliberately **not**
a data table — see Design Commandment against dense grids.
**Anatomy:** optional leading icon/thumb, title + meta (`.row-main`), an
optional badge, an optional trailing value.
**Accessibility:** When the whole row is a link, the link wraps the full
row (min. 44px height) rather than using a separate small "view" link.

### Sale / receipt row (accordion) — `.sale-row`
**Purpose:** A row that expands in place to show line-item detail, used
on Sales and Receipts, instead of navigating to a separate detail page for
read-only history.
**Behavior:** `data-accordion-toggle` / `data-accordion-panel` (generic,
see `interactions.js`); chevron rotates 180° on open.

### Empty state — `.empty-state`
**Purpose:** Any list/result with zero items. Always: an icon, a plain
-language headline, and — where relevant — one actionable next step.
**Misuse to avoid:** Never a bare "No data" string. Never a decorative
illustration/mascot (explicitly prohibited by the brief).

### Skeleton — `.skeleton`, `.skeleton-line`, `.skeleton-title`
**Purpose:** First-paint loading placeholder for any async content. Not
actively triggered in this static prototype (data is inline), but the
component is complete and ready for Codex's live data loads.

### Toast — `.toast`, `.toast-region`
**Purpose:** Brief, non-blocking confirmation of a background action
("Product added," "Inventory updated").
**Behavior:** Auto-dismisses after 5s or on manual close; `role="status"
aria-live="polite"` on the region so screen readers announce it without
interrupting.
**Misuse to avoid:** Never use a toast for anything the owner must act on
— that belongs in a banner or a confirmation dialog instead.

### Modal — `.modal`, `.overlay-scrim`
**Purpose:** Focused, blocking tasks — Add Product, and the two success
confirmations (sale recorded, receipt confirmed).
**Behavior:** Opens via `[data-modal-open="id"]`, closes via
`[data-modal-close]`, click-outside, or **Escape**. Focus moves to the
first focusable element on open.
**Known gap (documented for Codex):** focus is not currently *trapped*
inside the open modal — Tab can still reach the page behind it. This must
be fixed in the production build; see `ACCESSIBILITY_SPECIFICATION.md`.

### Drawer — `.drawer`
**Purpose:** Mobile-only secondary navigation (Reports, Settings, Search,
Notifications, Sign out) reached via the topbar hamburger.
**Behavior:** Slides in from the right; same open/close/Escape pattern as
the modal.

### Tabs — `.tabs`, `[data-tab-panel]`
**Purpose:** Switching between related views without changing screens
(Product Detail: Recent sales / Related receipts / History).
**Behavior:** `data-tabs-group` links a `.tabs` bar to its panels so
multiple independent tab groups can exist on one page without collision.

### Progress bar — `.progress-track` / `.progress-fill`
**Purpose:** The Receipt Review "X of Y items ready" indicator. The only
"chart-like" element outside Reports, and it's a literal, direct answer to
one question — not decoration.

### Banner — `.banner`
**Purpose:** A persistent, in-context message tied to the content around
it (insufficient stock warning on Record Sale, photo-quality tip on
Receipt Upload).
**Tones:** `-warning` `-danger` `-info` `-offline`.
**Difference from toast:** Banners stay until the underlying condition
changes; toasts disappear on their own.

### Dropzone — `.dropzone`
**Purpose:** Receipt capture (drag, take photo, upload).
**States:** idle, `.is-dragover`, loading (spinner + message), done
(success + CTA to review). See `receipt-upload.html` for the exact
three-state markup pattern.

### Review line — `.review-line`
**Purpose:** One line item inside Receipt Review.
**States (mutually exclusive):** `.state-ready` `.state-attention`
`.state-new` `.state-unreadable` — each with its own icon, tint, and
available actions. This is the component most directly responsible for
making AI-assisted processing feel understandable; see
`INTERACTION_SPECIFICATION.md` for its full behavior contract.

### Notification item — `.notif-item`, `.notif-dot`
**Purpose:** One entry in the Notifications list.
**States:** `.is-unread` (cream background + filled dot) / read (dot
becomes `.is-read`, transparent).

### Brand mark — `.brand-mark`, `.brand-glyph`, `.brand-word`
**Purpose:** The Tindahan logo lockup, used in the sidebar header, the
sign-in panel, onboarding, and the mobile drawer. Source asset:
`assets/images/tindahan-logo.svg`.

### Switch — `.switch`
**Purpose:** Binary on/off preferences (Settings, onboarding).
**Accessibility:** The `<input type="checkbox">` inside always carries its
own `aria-label` — do not rely on the wrapping `<label>` alone, since it
has no text content (only decorative track/thumb spans).

### Stat display — `.stat-value`, `.stat-label`, `.stat-delta`
**Purpose:** A single number with context (Dashboard summary, Sales
totals). Always paired with a label; deltas always carry a directional
icon, not color alone.

### Step indicator — `.step-indicator`, `.step-dot`
**Purpose:** Progress through a short linear flow (Onboarding, sign-in
visual panel).
